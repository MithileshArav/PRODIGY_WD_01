# PRODIGY_WD_01
A Responsive Landing page made for Prodigy Infotech Virtual Internship.
